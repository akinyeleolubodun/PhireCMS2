<?php

/**
 * Define the system document root
 * (open_base restrictions must be off)
 *
 * IMPORTANT: The BASE_PATH must be the same as the main system site.
 */
$systemDocRoot = '/home/nick/Projects/PhireCMS2';

// Calculate and define the base path
$basePath = str_replace(array(realpath($_SERVER['DOCUMENT_ROOT']), '\\'), array('', '/'), realpath(__DIR__));
define('BASE_PATH', (!empty($basePath) ? $basePath : ''));

try {
    require_once $systemDocRoot . DIRECTORY_SEPARATOR . BASE_PATH . DIRECTORY_SEPARATOR . 'bootstrap.php';
    $project->load($autoloader, $systemDocRoot)
            ->run();
} catch (Exception $e) {
    echo $e->getMessage();
}
