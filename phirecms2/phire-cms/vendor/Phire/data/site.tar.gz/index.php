<?php

// Calculate and define the base path
$basePath = str_replace(array(realpath($_SERVER['DOCUMENT_ROOT']), '\\'), array('', '/'), realpath(__DIR__));
define('BASE_PATH', (!empty($basePath) ? $basePath : ''));

$systemDocRoot = '/home/nick/Projects/PhireCMS2';

try {
    // Change to $systemDocRoot . '/base_path/bootstrap.php'
    require_once $systemDocRoot . DIRECTORY_SEPARATOR . BASE_PATH . DIRECTORY_SEPARATOR . 'bootstrap.php';
    $project->load($autoloader, $systemDocRoot)
            ->run();
} catch (Exception $e) {
    echo $e->getMessage();
}
